﻿// 
//

#include "pch.h"
#include <iostream>
#include <windows.h>　//丸を　描くために　必要です。
#include <vector>


using namespace std;

class color//色が　rand()関数によって　ランダムにしていされます。
{
public:
	int red, green, blue;
	color()
	{
		red = rand() % 256;
		green = rand() % 256;
		blue = rand() % 256; 
		
	}
};

class circle
{
	int q, w, e;
	color r;
public:
	circle(int q, int w, int e, color c) : q(q), w(w), e(e), r(c)//　横、縦、半径、色　
	{}
	void draw()//　丸を　画面に　描くための　コード
	{
		int t = e / 2;
		HDC hdc = GetWindowDC(GetForegroundWindow());//丸を　出力するための　コード　その１
		SelectObject(hdc, GetStockObject(DC_BRUSH));//色を　塗るための　コード　その１
		SetDCBrushColor(hdc, RGB(r.red, r.green, r.blue)); //色を　塗るための　コード　その２（二つ　全て　入力しないと　白い　丸が　描かれます。）
		Ellipse(hdc, q - t, w - t, q + t, w + t);//丸を　出力するための　コード　その２（二つ　全て　入力しないと　何も出力されません。）


	}

	
};




int main()
{
	for (int i = 0; i < 1000; i++)//１０００個の　丸が　描かれます。
	{
		circle s(rand() % 500, rand() % 400, rand() % 50, color());
		//横（５００）、縦（４００）の　範囲内に　半径５０の　様々な　色の　丸が　描かれます。　
		s.draw();
	
	}
	return 0;
}
