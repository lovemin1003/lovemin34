package graphics;


import java.awt.*; 
import java.awt.event.*;



 class design extends Frame implements ActionListener {
	 
	 private Image img = Toolkit.getDefaultToolkit().getImage("37612267_p0_master1200.jpg");//イメージを　設定します。
	 private Button bt1 = new Button("up");//ボタンの　名前を　設定します。
	 private Button bt2 = new Button("down");
	 private Button bt3 = new Button("main");
	 private Button bt4 = new Button("close");
   	 private int Height=300;//最初の　絵の幅を　設定します。
	 private int Width =300;
	 
	 private Panel p = new Panel();//ボタンを　作ります。
  	 private GridLayout gl = new GridLayout(1,4);//ボタンが　どのように　出るか　設定します。（この場合は　横に　四つ　出ます。）
   	 private BorderLayout bl = new BorderLayout();//画面を　出力させるための　コード
	 

	
	 public void init() {
		
		 this.setLayout(bl);
         this.add("South",p);//下（南(south））に　ボタンが　出ます。　　		 
         p.setLayout(gl);
         p.add(bt1);
         p.add(bt2);
         p.add(bt3); 
         p.add(bt4);

	 bt1.addActionListener(this); //ボタンに　設定した　命令を　遂行します。
	 bt2.addActionListener(this);
	 bt3.addActionListener(this);
	 bt4.addActionListener(this);
	 
	 }
	 public void paint(Graphics g) {
		 
		 g.drawImage(img,200,200,Width,Height,this);//絵の位置を設定します。
		 
	 }
   
    	public design() {
    	this.init();
    	super.setSize(1000, 1000);//画面の　広さを　設定します。
    	
    	
  
		Dimension di = Toolkit.getDefaultToolkit().getScreenSize();//システムの画面の　幅を　持って来る
		
		int xpos = (int)(di.getWidth()/2 - this.getWidth()/2);
	    int ypos = (int)(di.getHeight()/2 - this.getHeight()/2);
	    //システムの画面の　真ん中に　現在の　フレームを　アップするための　計算
	    
	    super.setLocation(xpos,ypos);
	    super.setResizable(true);//画面の　幅の増減可能の　可否の　設定　
	    super.setVisible(true);//最後に　画面に見せるのは　セッティング後　ユーザーに　見せるため。
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			if(e.getSource()==bt1)
			{
				Width+=30;//絵の幅を　３０位　増加させます。
				Height=Width;
				if(Width>600)//絵の幅の最大値を６００に設定しました。
				{
					Width=600;
				}
			}
			else if(e.getSource()==bt2)
			{
				Width-=30;//絵の幅を　３０位　減少させます。
				Height=Width;
				if(Width<200)//絵の幅の最小値を２００に設定しました。
				{
					Width=200;
				}
			}
			else if(e.getSource()==bt3)//絵の幅を　元に戻します。
			{
				Width =300;
				Height=Width;
			}
			else if(e.getSource()==bt4)//closeを押すと　画面が　消えます。
			{
				System.exit(0);
			}
			repaint();
		}
		
	
}
public class illust {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		design choco= new design();
	}

}
