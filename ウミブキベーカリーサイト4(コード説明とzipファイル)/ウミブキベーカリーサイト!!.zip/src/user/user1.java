package user;

public class user1 
{

	private String userid;
	private String userpassword;
	private String username;
	private String usergender;
	private String useremail;
	private int count;
	
	
	
	public String getUserid()
	{
		return userid;
	}
	public void setUserid(String userid) 
	{
		this.userid = userid;
	}
	public String getUserpassword()
	{
		return userpassword;
	}
	public void setUserpassword(String userpassword)
	{
		this.userpassword = userpassword;
	}
	public String getUsername() 
	{
		return username;
	}
	public void setUsername(String username)
	{
		this.username = username;
	}
	public String getUsergender()
	{
		return usergender;
	}
	public void setUsergender(String usergender)
	{
		this.usergender = usergender;
	}
	public String getUseremail() 
	{
		return useremail;
	}
	public void setUseremail(String useremail)
	{
		this.useremail = useremail;
	}
	public int getCount() {
		return count;
	}
	public void setCount(int count) {
		this.count = count;
	}
}
