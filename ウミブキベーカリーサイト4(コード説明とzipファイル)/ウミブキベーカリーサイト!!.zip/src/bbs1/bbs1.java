package bbs1;

public class bbs1 {

	private int bbsid;
	private String userid;
	private String bbsdate;
	private String bbscontent1;
	private int bbsavailable;
    private String username;
    private int commentid;
    private String filename;
    
	public int getBbsid() {
		return bbsid;
	}
	public void setBbsid(int bbsid) {
		this.bbsid = bbsid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getBbsdate() {
		return bbsdate;
	}
	public void setBbsdate(String bbsdate) {
		this.bbsdate = bbsdate;
	}
	public String getBbscontent1() {
		return bbscontent1;
	}
	public void setBbscontent1(String bbscontent1) {
		this.bbscontent1 = bbscontent1;
	}
	public int getBbsavailable() {
		return bbsavailable;
	}
	public void setBbsavailable(int bbsavailable) {
		this.bbsavailable = bbsavailable;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getCommentid() {
		return commentid;
	}
	public void setCommentid(int commentid) {
		this.commentid = commentid;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	

}
